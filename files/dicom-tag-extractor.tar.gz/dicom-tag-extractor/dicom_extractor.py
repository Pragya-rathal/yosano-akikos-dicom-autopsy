"""
dicom_extractor.py
==================
Loads every .dcm file from a folder and extracts a configurable set of DICOM
tags into a single JSON file.

Usage
-----
    python dicom_extractor.py --input ./dicoms --output metadata.json

Install dependency first:
    pip install pydicom

Author: your name
"""

import argparse
import json
import os
import sys
from pathlib import Path
from datetime import datetime

try:
    import pydicom
    from pydicom.errors import InvalidDicomError
except ImportError:
    sys.exit(
        "pydicom is not installed. Run:  pip install pydicom"
    )


# ---------------------------------------------------------------------------
# 1.  TAG DEFINITIONS
#     Each entry maps a friendly key to a DICOM keyword string.
#     pydicom understands keyword strings natively — no need to look up hex IDs.
# ---------------------------------------------------------------------------
DEFAULT_TAGS = {
    "PatientID":          "PatientID",           # (0010,0020)
    "PatientName":        "PatientName",          # (0010,0010)
    "PatientBirthDate":   "PatientBirthDate",     # (0010,0030)
    "PatientSex":         "PatientSex",           # (0010,0040)
    "Modality":           "Modality",             # (0008,0060)  e.g. CT, MR, CR
    "StudyDate":          "StudyDate",            # (0008,0020)  YYYYMMDD
    "StudyTime":          "StudyTime",            # (0008,0030)  HHMMSS.ffffff
    "StudyDescription":   "StudyDescription",     # (0008,1030)
    "StudyInstanceUID":   "StudyInstanceUID",     # (0020,000D)  globally unique
    "SeriesDescription":  "SeriesDescription",    # (0008,103E)
    "SeriesNumber":       "SeriesNumber",         # (0020,0011)
    "SOPInstanceUID":     "SOPInstanceUID",       # (0008,0018)  identifies one image
    "BodyPartExamined":   "BodyPartExamined",     # (0018,0015)
    "InstitutionName":    "InstitutionName",      # (0008,0080)
    "Manufacturer":       "Manufacturer",         # (0008,0070)
}


# ---------------------------------------------------------------------------
# 2.  READING A SINGLE FILE
# ---------------------------------------------------------------------------
def extract_tags(dcm_path: Path, tags: dict) -> dict:
    """
    Open one .dcm file and return a dict of the requested tag values.

    pydicom exposes every tag as an attribute on the Dataset object.
    ds.get(keyword, None) is safer than ds.keyword — it won't raise
    AttributeError if the tag is absent (many DICOM files omit optional tags).
    """
    result = {
        "file": dcm_path.name,
        "path": str(dcm_path),
        "extracted_at": datetime.utcnow().isoformat() + "Z",
        "tags": {},
        "errors": [],
    }

    try:
        # stop_before_pixels=True skips the heavy pixel data array.
        # This is a big win for speed when you only need metadata.
        ds = pydicom.dcmread(str(dcm_path), stop_before_pixels=True)

        for label, keyword in tags.items():
            raw = ds.get(keyword)          # returns a DataElement or None

            if raw is None:
                result["tags"][label] = None
                continue

            value = raw.value              # the Python value inside the element

            # pydicom returns some values as specialised types.
            # Convert them so json.dumps() won't complain.
            if hasattr(value, "__str__"):
                value = str(value)         # covers PersonName, UID, etc.

            result["tags"][label] = value

    except InvalidDicomError as exc:
        result["errors"].append(f"Not a valid DICOM file: {exc}")
    except Exception as exc:              # noqa: BLE001
        result["errors"].append(f"Unexpected error: {exc}")

    return result


# ---------------------------------------------------------------------------
# 3.  SCANNING A FOLDER
# ---------------------------------------------------------------------------
def scan_folder(folder: Path, tags: dict, recursive: bool = False) -> list[dict]:
    """
    Walk a folder and extract tags from every .dcm file found.
    Set recursive=True to search sub-folders as well.
    """
    pattern = "**/*.dcm" if recursive else "*.dcm"
    dcm_files = sorted(folder.glob(pattern))

    if not dcm_files:
        print(f"[warn] No .dcm files found in {folder}")
        return []

    print(f"[info] Found {len(dcm_files)} .dcm file(s). Extracting tags …")

    results = []
    for i, path in enumerate(dcm_files, 1):
        record = extract_tags(path, tags)

        # Show a simple progress line in the terminal
        status = "OK" if not record["errors"] else "ERR"
        print(f"  [{i:>4}/{len(dcm_files)}] {status}  {path.name}")

        results.append(record)

    return results


# ---------------------------------------------------------------------------
# 4.  WRITING OUTPUT
# ---------------------------------------------------------------------------
def write_json(records: list[dict], output_path: Path) -> None:
    """Serialise results to a pretty-printed JSON file."""
    payload = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "total_files":  len(records),
        "records":      records,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, ensure_ascii=False, default=str)

    print(f"\n[done] Written → {output_path}  ({output_path.stat().st_size:,} bytes)")


# ---------------------------------------------------------------------------
# 5.  CLI ENTRY POINT
# ---------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Extract DICOM metadata tags into JSON.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python dicom_extractor.py --input ./studies --output metadata.json
  python dicom_extractor.py --input ./studies --output out.json --recursive
  python dicom_extractor.py --input ./studies --output out.json --tags PatientID Modality
        """,
    )
    parser.add_argument(
        "--input", "-i",
        type=Path,
        required=True,
        help="Folder containing .dcm files",
    )
    parser.add_argument(
        "--output", "-o",
        type=Path,
        default=Path("dicom_metadata.json"),
        help="Output JSON file path (default: dicom_metadata.json)",
    )
    parser.add_argument(
        "--recursive", "-r",
        action="store_true",
        help="Search sub-folders recursively",
    )
    parser.add_argument(
        "--tags",
        nargs="+",
        metavar="TAG",
        help=(
            "Space-separated DICOM keywords to extract. "
            "If omitted, uses the built-in default set. "
            "Example: --tags PatientID Modality StudyDate"
        ),
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # Resolve which tags to extract
    if args.tags:
        # User supplied their own list — map each keyword to itself
        tags = {kw: kw for kw in args.tags}
        print(f"[info] Extracting {len(tags)} custom tag(s): {', '.join(tags)}")
    else:
        tags = DEFAULT_TAGS
        print(f"[info] Extracting {len(tags)} default tag(s)")

    # Validate input folder
    if not args.input.is_dir():
        sys.exit(f"[error] Input path is not a directory: {args.input}")

    # Run extraction
    records = scan_folder(args.input, tags, recursive=args.recursive)

    if not records:
        sys.exit(0)

    # Write output
    write_json(records, args.output)


if __name__ == "__main__":
    main()
