# dicom-tag-extractor

A lightweight CLI tool that scans a folder of `.dcm` files and extracts
configurable DICOM metadata tags into structured JSON.

Built as a foundation for medical imaging metadata ingestion pipelines.

## Features

- Extracts 14 default tags (PatientID, Modality, StudyDate, SOPInstanceUID, …)
- Custom tag lists via `--tags`
- Recursive folder scan with `--recursive`
- Graceful error handling — bad files are logged, not crashes
- Fast: `stop_before_pixels=True` skips heavy pixel arrays
- Full test suite using **pydicom's built-in test files** (no data download needed)

## Quick start

```bash
git clone https://github.com/yourname/dicom-tag-extractor
cd dicom-tag-extractor
pip install -r requirements.txt

# extract from a folder
python dicom_extractor.py --input ./dicoms --output metadata.json

# only 3 tags, recursive
python dicom_extractor.py --input ./studies -o out.json --recursive \
  --tags PatientID Modality StudyDate

# run against pydicom's own built-in test files (no .dcm files needed)
python demo_with_pydicom_data.py
```

## Output shape

```json
{
  "generated_at": "2024-03-15T10:42:00Z",
  "total_files": 42,
  "records": [
    {
      "file": "CT_small.dcm",
      "path": "/dicoms/CT_small.dcm",
      "extracted_at": "2024-03-15T10:42:01Z",
      "tags": {
        "PatientID": "1CT1",
        "Modality":  "CT",
        "StudyDate": "20040119",
        "Rows": "128",
        "Columns": "128"
      },
      "errors": []
    }
  ]
}
```

## Running tests

```bash
pip install pytest pydicom
pytest tests/ -v
```

Tests use pydicom's bundled sample files — CT, MR, CR, US — so they work
offline with zero extra setup.

## Default tags extracted

| Key | DICOM keyword | Tag |
|-----|--------------|-----|
| PatientID | PatientID | (0010,0020) |
| PatientName | PatientName | (0010,0010) |
| Modality | Modality | (0008,0060) |
| StudyDate | StudyDate | (0008,0020) |
| StudyDescription | StudyDescription | (0008,1030) |
| SeriesDescription | SeriesDescription | (0008,103E) |
| SOPInstanceUID | SOPInstanceUID | (0008,0018) |
| StudyInstanceUID | StudyInstanceUID | (0020,000D) |
| SeriesNumber | SeriesNumber | (0020,0011) |
| BodyPartExamined | BodyPartExamined | (0018,0015) |
| InstitutionName | InstitutionName | (0008,0080) |
| Manufacturer | Manufacturer | (0008,0070) |

## What's next

- [ ] Deduplicate by `StudyInstanceUID`
- [ ] Group files into Study → Series → Instance hierarchy
- [ ] Anonymisation mode (strip `PatientName`, `PatientID`)
- [ ] Export to CSV or SQLite
- [ ] WADO-RS / DICOMweb support

## Dataset sources for testing

pydicom ships ~100 built-in `.dcm` files — use `demo_with_pydicom_data.py`.

For larger real-world data:
- [TCIA (The Cancer Imaging Archive)](https://www.cancerimagingarchive.net) — free, public
- [Kaggle DICOM datasets](https://www.kaggle.com/datasets?search=dicom)
- [RSNA challenges](https://www.rsna.org/education/ai-resources-and-training/ai-image-challenge) — historical datasets

## License

MIT
